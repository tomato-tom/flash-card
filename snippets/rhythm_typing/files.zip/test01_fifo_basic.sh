#!/bin/bash
# test01_fifo_basic.sh
# FIFO通信の基本動作確認

echo "=== FIFO通信テスト ==="
echo "キーを押すとFIFO経由で受信します（qで終了）"
echo ""

FIFO_PATH="/tmp/test_fifo_$$"
mkfifo "$FIFO_PATH"

# クリーンアップ
cleanup() {
    rm -f "$FIFO_PATH"
    echo ""
    echo "終了"
    exit 0
}
trap cleanup EXIT INT TERM

# キー入力ハンドラー
key_handler() {
    local key
    while true; do
        if read -rsn1 -t 0.01 key; then
            echo "$key" > "$FIFO_PATH" &
        fi
        sleep 0.001
    done
}

# バックグラウンドで起動
key_handler &

# メインループ
counter=0
while true; do
    if read -t 0.1 key_press < "$FIFO_PATH"; then
        counter=$((counter + 1))
        echo "[$counter] 受信: '$key_press'"
        
        if [ "$key_press" = "q" ]; then
            echo "終了キー検出"
            break
        fi
    fi
done

cleanup
